/**
 * LOCAL MOCK CLIENT — replaces @base44/sdk for local development.
 * All data is stored in localStorage. No Base44 account needed.
 */

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

function getStore(name) {
  try { return JSON.parse(localStorage.getItem(`mock_db_${name}`) || '[]'); }
  catch { return []; }
}
function setStore(name, data) {
  localStorage.setItem(`mock_db_${name}`, JSON.stringify(data));
}
function sortRecords(records, sort) {
  if (!sort) return records;
  const desc = sort.startsWith('-');
  const field = desc ? sort.slice(1) : sort;
  return [...records].sort((a, b) => {
    const av = a[field] ?? '', bv = b[field] ?? '';
    if (av < bv) return desc ? 1 : -1;
    if (av > bv) return desc ? -1 : 1;
    return 0;
  });
}

function makeEntity(name) {
  return {
    list: async (sort, limit) => {
      let rows = sortRecords(getStore(name), sort);
      return limit ? rows.slice(0, limit) : rows;
    },
    filter: async (filterObj, sort, limit) => {
      let rows = getStore(name).filter(row =>
        Object.entries(filterObj ?? {}).every(([k, v]) => row[k] === v)
      );
      rows = sortRecords(rows, sort);
      return limit ? rows.slice(0, limit) : rows;
    },
    get: async (id) => getStore(name).find(r => r.id === id) ?? null,
    create: async (data) => {
      const rows = getStore(name);
      const record = { id: uid(), created_date: new Date().toISOString(), updated_date: new Date().toISOString(), ...data };
      rows.push(record);
      setStore(name, rows);
      return record;
    },
    update: async (id, data) => {
      const rows = getStore(name);
      const idx = rows.findIndex(r => r.id === id);
      if (idx === -1) throw new Error(`${name}:${id} not found`);
      rows[idx] = { ...rows[idx], ...data, updated_date: new Date().toISOString() };
      setStore(name, rows);
      return rows[idx];
    },
    delete: async (id) => {
      setStore(name, getStore(name).filter(r => r.id !== id));
      return { id };
    },
  };
}

async function InvokeLLM({ prompt, response_json_schema }) {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
  if (!apiKey) {
    // Return a believable fake when no API key is set
    if (response_json_schema) {
      return { summary: 'Add last_login column to users table', status: 'In Progress', assignee: 'Jane Smith' };
    }
    return 'AI response (set VITE_ANTHROPIC_API_KEY in .env.local for real responses)';
  }
  const isJson = !!response_json_schema;
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 512,
      system: isJson ? 'Respond ONLY with valid JSON. No markdown, no extra text.' : 'You are a helpful assistant.',
      messages: [{ role: 'user', content: prompt }],
    }),
  });
  if (!res.ok) throw new Error(`API error: ${await res.text()}`);
  const data = await res.json();
  const text = data.content?.find(b => b.type === 'text')?.text ?? '';
  if (isJson) {
    try { return JSON.parse(text.replace(/```json|```/g, '').trim()); }
    catch { return {}; }
  }
  return text;
}

export const base44 = {
  entities: {
    ChangeRequest: makeEntity('ChangeRequest'),
    DeploymentLog: makeEntity('DeploymentLog'),
    WebhookConfig: makeEntity('WebhookConfig'),
  },
  integrations: { Core: { InvokeLLM } },
  auth: {
    me: async () => ({ id: 'local-user', email: 'dev@local.test', name: 'Local Dev' }),
    logout: () => {},
    redirectToLogin: () => {},
  },
};
