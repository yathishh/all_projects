# DB Pipeline CI/CD — Local Development

A database change request management tool with a full CI/CD pipeline:
**Local Test → DBA Staging Review → Staging Deploy → DBA Prod Review → Production Deploy**

## Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn

### 1. Clone & install

```bash
git clone <your-repo-url>
cd ci-cd-local
npm install
```

### 2. Configure environment (optional)

```bash
cp .env.local.example .env.local
```

Edit `.env.local` — only needed if you want the AI-powered "Fetch Jira" button:

```
VITE_ANTHROPIC_API_KEY=sk-ant-...
```

Get a free key at https://console.anthropic.com

### 3. Run locally

```bash
npm run dev
```

Open http://localhost:5173

## How it works locally

All data is stored in **browser localStorage** — no backend, no database needed.
Data persists across page refreshes. To reset, open DevTools → Application → Local Storage → delete all `mock_db_*` keys.

## App Pages

| Route | Description |
|---|---|
| `/` | Dashboard — stats, pipeline overview, recent changes |
| `/changes` | All change requests |
| `/changes/new` | Create a new DB migration change request |
| `/changes/:id` | Change detail with pipeline actions |
| `/local-test` | Run/simulate local migration tests |
| `/approvals` | DBA approval queue for staging & prod |
| `/history` | Full deployment log history |
| `/environments` | Environment config |
| `/webhooks` | MS Teams webhook notification settings |

## Pipeline Statuses

```
draft → pending_local → local_passed/failed
  → pending_staging_approval → staging_approved/rejected
  → pending_staging_deploy → staging_passed/failed
  → pending_prod_approval → prod_approved/rejected
  → prod_deployed / prod_failed / rolled_back
```

## Tech Stack

- **React 18** + **Vite 6**
- **Tailwind CSS** + **shadcn/ui**
- **React Router v6**
- **TanStack Query v5**
- **date-fns**, **lucide-react**

## Key Changes from Original

This is a standalone fork of the original Base44-hosted app. Changes made:
- `src/api/base44Client.js` — replaced with a localStorage mock client
- `src/lib/AuthContext.jsx` — replaced with a mock that auto-logs you in
- `src/lib/app-params.js` — replaced with a stub
- `vite.config.js` — removed `@base44/vite-plugin`
- `package.json` — removed `@base44/sdk` and `@base44/vite-plugin`
